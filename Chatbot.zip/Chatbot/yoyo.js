function voice(){
    document.getElementsByClassName("chat-input").value="hello";
}